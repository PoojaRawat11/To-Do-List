function addList(){
  var li=document.createElement("li");
  var myInput=document.getElementById("myInput").value;
  var data=document.createTextNode(myInput);
  li.appendChild(data);
  if(myInput === ''){
    alert("Please enter your To-Do List");
  }
  else{
    document.getElementById("myUl").appendChild(li);
  }
  document.getElementById("myInput").value='';
    var span=document.createElement("span");
    // var closeIcon=document.createTextNode("\u00D7");
    var closeIcon=document.createElement("i");
    closeIcon.className="fa-sharp fa-solid fa-xmark del-icon";
    span.className="del-icon";
    span.appendChild(closeIcon);
    li.appendChild(span);
$("span").click(function(){
    $(this).parents('li').css("display","none");
});
}


var myNodeList=document.getElementsByTagName("li");
var i;
for(i=0; i<myNodeList.length; i++){
    var span=document.createElement("span");
    span.className="del-icon";
    var closeIcon=document.createElement("i");
    closeIcon.className="fa-sharp fa-solid fa-xmark del-icon";
    span.appendChild(closeIcon);
    myNodeList[i].appendChild(span);
}
